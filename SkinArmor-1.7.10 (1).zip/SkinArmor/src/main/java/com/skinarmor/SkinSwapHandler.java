package com.skinarmor;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.relauncher.ReflectionHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderPlayerEvent;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class SkinSwapHandler {
    private final Map<String, ResourceLocation> skins = new HashMap<String, ResourceLocation>();
    private final Map<AbstractClientPlayer, ResourceLocation> originals = new HashMap<AbstractClientPlayer, ResourceLocation>();
    private Field skinField;
    private boolean failed;

    private Field field() {
        if (skinField != null || failed) return skinField;
        try {
            // "locationSkin" (dev) / "field_110312_d" (ofuscado)
            skinField = ReflectionHelper.findField(AbstractClientPlayer.class, "locationSkin", "field_110312_d");
        } catch (Exception e) {
            // plano B: primeiro campo ResourceLocation não-estático (locationSkin vem antes de locationCape)
            for (Field f : AbstractClientPlayer.class.getDeclaredFields()) {
                if (f.getType() == ResourceLocation.class && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                    f.setAccessible(true);
                    skinField = f;
                    break;
                }
            }
            if (skinField == null) failed = true;
        }
        return skinField;
    }

    private ResourceLocation skin(String id) {
        ResourceLocation r = skins.get(id);
        if (r == null) {
            r = new ResourceLocation(SkinArmorMod.MODID, "textures/skins/" + id + ".png");
            skins.put(id, r);
        }
        return r;
    }

    private void swap(EntityPlayer p) {
        if (!(p instanceof AbstractClientPlayer)) return;
        AbstractClientPlayer ap = (AbstractClientPlayer) p;
        if (originals.containsKey(ap)) return;
        String id = ItemSkinArmor.getFullSetId(p);
        if (id == null) return;
        Field f = field();
        if (f == null) return;
        try {
            originals.put(ap, (ResourceLocation) f.get(ap));
            f.set(ap, skin(id));
        } catch (Exception e) {
            originals.remove(ap);
        }
    }

    private void restore(EntityPlayer p) {
        if (!(p instanceof AbstractClientPlayer)) return;
        AbstractClientPlayer ap = (AbstractClientPlayer) p;
        if (!originals.containsKey(ap)) return;
        try {
            field().set(ap, originals.remove(ap));
        } catch (Exception e) {
            originals.remove(ap);
        }
    }

    @SubscribeEvent
    public void onPre(RenderPlayerEvent.Pre e) {
        if (e.entityPlayer == Minecraft.getMinecraft().thePlayer) return; // tratado no RenderTick
        swap(e.entityPlayer);
    }

    @SubscribeEvent
    public void onPost(RenderPlayerEvent.Post e) {
        if (e.entityPlayer == Minecraft.getMinecraft().thePlayer) return;
        restore(e.entityPlayer);
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        EntityPlayer p = Minecraft.getMinecraft().thePlayer;
        if (p == null) return;
        if (e.phase == TickEvent.Phase.START) swap(p);
        else restore(p);
    }
}
