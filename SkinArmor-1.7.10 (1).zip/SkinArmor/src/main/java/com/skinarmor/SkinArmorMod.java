package com.skinarmor;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

@Mod(modid = SkinArmorMod.MODID, name = "Skin Armor", version = "1.0")
public class SkinArmorMod {
    public static final String MODID = "skinarmor";

    /** Um conjunto por skin. Cada id tem de existir em textures/skins/<id>.png */
    public static final String[] SETS = {"skin8", "larpspok", "laranja"};
    /** Ordem = índice de slot do ItemArmor (0 capacete, 1 peitoral, 2 calças, 3 botas) */
    public static final String[] PARTS = {"helmet", "chestplate", "leggings", "boots"};

    public static final Item[][] ITEMS = new Item[SETS.length][4];

    @SidedProxy(clientSide = "com.skinarmor.ClientProxy", serverSide = "com.skinarmor.CommonProxy")
    public static CommonProxy proxy;

    public static final CreativeTabs TAB = new CreativeTabs("skinarmor") {
        @Override
        public Item getTabIconItem() {
            return ITEMS[0][1];
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        ArmorMaterial mat = EnumHelper.addArmorMaterial("SKINARMOR", 25, new int[]{2, 6, 5, 2}, 12);
        for (int i = 0; i < SETS.length; i++) {
            for (int s = 0; s < 4; s++) {
                ITEMS[i][s] = new ItemSkinArmor(mat, s, SETS[i]);
                GameRegistry.registerItem(ITEMS[i][s], SETS[i] + "_" + PARTS[s]);
            }
        }
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        // Receitas: material de cada conjunto
        Object[] mats = {Items.diamond, Items.coal, Blocks.pumpkin};
        for (int i = 0; i < SETS.length; i++) {
            Object m = mats[i];
            GameRegistry.addRecipe(new ItemStack(ITEMS[i][0]), "XXX", "X X", 'X', m);
            GameRegistry.addRecipe(new ItemStack(ITEMS[i][1]), "X X", "XXX", "XXX", 'X', m);
            GameRegistry.addRecipe(new ItemStack(ITEMS[i][2]), "XXX", "X X", "X X", 'X', m);
            GameRegistry.addRecipe(new ItemStack(ITEMS[i][3]), "X X", "X X", 'X', m);
        }
        proxy.init();
    }
}
