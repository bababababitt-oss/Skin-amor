package com.skinarmor;

public class CommonProxy {
    public void init() {}
}
