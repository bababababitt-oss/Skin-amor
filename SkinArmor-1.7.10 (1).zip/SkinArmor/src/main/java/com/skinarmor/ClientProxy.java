package com.skinarmor;

import cpw.mods.fml.common.FMLCommonHandler;
import net.minecraftforge.common.MinecraftForge;

public class ClientProxy extends CommonProxy {
    @Override
    public void init() {
        SkinSwapHandler h = new SkinSwapHandler();
        MinecraftForge.EVENT_BUS.register(h);             // RenderPlayerEvent (outros jogadores)
        FMLCommonHandler.instance().bus().register(h);    // RenderTickEvent (você, incl. mão em 1ª pessoa)
    }
}
