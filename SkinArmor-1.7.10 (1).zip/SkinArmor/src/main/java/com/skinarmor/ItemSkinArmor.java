package com.skinarmor;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class ItemSkinArmor extends ItemArmor {
    public final String setId;
    private final int slot;

    public ItemSkinArmor(ArmorMaterial mat, int slot, String setId) {
        super(mat, 0, slot);
        this.slot = slot;
        this.setId = setId;
        String name = setId + "_" + SkinArmorMod.PARTS[slot];
        setUnlocalizedName(SkinArmorMod.MODID + "." + name);
        setTextureName(SkinArmorMod.MODID + ":" + name);
        setCreativeTab(SkinArmorMod.TAB);
    }

    /** Camada de armadura 100% transparente: só a skin muda, nada aparece por cima. */
    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
        return SkinArmorMod.MODID + ":textures/models/armor/blank_layer_" + (this.slot == 2 ? 2 : 1) + ".png";
    }

    /** Devolve o id do conjunto se o jogador veste as 4 peças do MESMO conjunto, senão null. */
    public static String getFullSetId(EntityPlayer p) {
        String id = null;
        for (int i = 1; i <= 4; i++) { // 1 botas .. 4 capacete
            ItemStack st = p.getEquipmentInSlot(i);
            if (st == null || !(st.getItem() instanceof ItemSkinArmor)) return null;
            String cur = ((ItemSkinArmor) st.getItem()).setId;
            if (id == null) id = cur;
            else if (!id.equals(cur)) return null;
        }
        return id;
    }
}
